from flask import Blueprint, request, Response
from classes.plugin import Plugin
from classes.browser import Firefox
from classes.net import NET
from classes.imdb import IMDB
from utils.addonSettings import setAddonSetting, getAddonSetting
from utils.users import reqToToken
import difflib
from bs4 import BeautifulSoup

n123moviesfree = Blueprint("123moviesfree", __name__)


@n123moviesfree.route('/playlist.m3u8')
def playlist():
    url = request.args.get('url')
    if not url:
        return ""
    firefox = Firefox()
    firefox.addHeader("Referer", "https://player.voxzer.org")

    r = NET().GET(
        url,
        headers=firefox.headers,
        usePHPProxy=getAddonSetting("123moviesfree", "phpProxyEnabled").lower() == "true",
        useProxy=getAddonSetting("123moviesfree", "useProxy").lower() == "true"
    )
    m3u8 = []
    for line in r.text.split("\n"):
        if not line:
            continue

        if line.startswith("http"):
            m3u8.append(f"/p/123moviesfree/chunk.ts?url={line}&token={reqToToken(request)}")
        else:
            m3u8.append(line)
    return Response("\n".join(m3u8), mimetype='application/x-mpegURL')


@n123moviesfree.route('/chunk.ts')
def chunk():
    url = request.args.get('url')
    if not url:
        return ""

    firefox = Firefox()
    firefox.addHeader("Referer", "https://player.voxzer.org")

    r = NET().GET(
        url,
        headers=firefox.headers,
        usePHPProxy=getAddonSetting("123moviesfree", "phpProxyEnabled").lower() == "true",
        useProxy=getAddonSetting("123moviesfree", "useProxy").lower() == "true"
    )
    return r.content

class n123moviesfreeClass(Plugin):
    def __init__(self) -> None:
        self.metadata = {
            "name": "123moviesfree",
            "desc": "Plugin for grabbing streams from 123moviesfree.net",
            "author": "Parrot Developers",
            "id": "123moviesfree",
            "logo": "logo.jpg",
            "resolver": {
                "name": "123moviesfree",
                "func": self.resolve,
            },
            "settings": ["phpProxyEnabled", "useProxy"]
        }

        if not getAddonSetting("123moviesfree", "phpProxyEnabled"):
            setAddonSetting("123moviesfree", "phpProxyEnabled", "false")

        if not getAddonSetting("123moviesfree", "useProxy"):
            setAddonSetting("123moviesfree", "useProxy", "false")
    
    def search(self, headers, type, episode, query, year):
        database = NET().GET(
            "https://ww1.123moviesfree.net/movies.json",
            headers=headers,
            usePHPProxy=getAddonSetting("123moviesfree", "phpProxyEnabled").lower() == "true",
            useProxy=getAddonSetting("123moviesfree", "useProxy").lower() == "true"
        ).json()
        names, slugs = [], []
        for item in database:
            if item["type"] != type: continue
            names.append(item["title"])
            slugs.append(item["slug"])

        if episode:
            query = f"{query} - {episode.split('-')[0]}"

        closest = difflib.get_close_matches(query, names, n=10, cutoff = 0.5)
        seq = ((e, difflib.SequenceMatcher(None, query, e).get_matching_blocks()[0]) for e in closest)
        seq = [k for k, _ in sorted(seq, key = lambda e:e[-1].size, reverse = True)]
        best = slugs[names.index(seq[0])]

        if type == "movies":
            return f"https://ww1.123moviesfree.net/movie/{best}/watching.html"
        else:
            return f"https://ww1.123moviesfree.net/season/{best}/watching.html"




    def resolve(self, imdbid, episode=None):
        data = IMDB().getMovieInfo(imdbid)
        name = data["title"]
        try:
            year = data["year"]
        except:
            year = ""
        firefox = Firefox()
        firefox.addHeader("Referer", "https://ww1.123moviesfree.net")
        url = self.search(firefox.headers, "series" if episode else "movies", episode, name, year)
        html = NET().GET(
            url,
            headers=firefox.headers,
            usePHPProxy=getAddonSetting("123moviesfree", "phpProxyEnabled").lower() == "true",
            useProxy=getAddonSetting("123moviesfree", "useProxy").lower() == "true"
        ).text
        soup = BeautifulSoup(html, features="html.parser")
        sources = soup.find_all("div", {"class": "les-content"})[0]

        if episode:
            episode = episode.split("-")[1]
        else:
            episode = "1"

        embedURL = sources.find_all("a", {"episode-id": episode})[0]["onclick"].split("load_episode_video('")[1].split("'")[0]
        firefox.addHeader("Referer", "https://player.voxzer.org")
        m3u8 = NET().GET(
            embedURL.replace("/view/", "/list/"), 
            headers=firefox.headers,
            usePHPProxy=getAddonSetting("123moviesfree", "phpProxyEnabled").lower() == "true",
            useProxy=getAddonSetting("123moviesfree", "useProxy").lower() == "true"
        ).json()["link"]

        return f"/p/123moviesfree/playlist.m3u8?url={m3u8}&token=[[token]]"


    # Required
    def blueprint(self) -> Blueprint:
        return n123moviesfree
